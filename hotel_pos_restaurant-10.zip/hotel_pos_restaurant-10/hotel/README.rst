hotel

This Module is for Providing Hotel management Features. 

You can manage:
-Hotel Booking,
-Hotel Facilities and Amenities,
-RESTURANTS,
-Currency Exchange,
-REPORTS

-Different reports are also provided, mainly for hotel.

Installation

To install this module, you need to:

install 'sale_stock', 'point_of_sale', 'report' modules

Configuration

To configure this module, you need to:

have a Hotel management functionality.

Usage

To use this module, you need to:

go to apps, then install module to apply this functionality.

Try me on Runbot
Known issues / Roadmap

...

Bug Tracker

Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported. If you spotted it first, help us smashing it by providing a detailed and welcomed feedback here.

Credits

Contributors

Serpent Consulting Services PVT. LTD. <http://serpentcs.com>

Maintainer

Serpent Consulting Services PVT. LTD.

This module is maintained by the SerpentCS.

To contribute to this module, please visit https://github.com/JayVora-SerpentCS/OdooHotelManagementSystem.
